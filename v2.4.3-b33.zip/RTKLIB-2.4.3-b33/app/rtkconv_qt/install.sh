cp rtkconv_qt ../../../RTKLIB_bin/bin
